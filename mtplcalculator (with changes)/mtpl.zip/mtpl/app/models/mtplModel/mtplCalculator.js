const { verifyToken } = require("../../utils/authUtils");
const User = require("../userModel/userModel")

module.exports = (sequelize, Sequelize) => {
    const MtplCalculator = sequelize.define("mtplcalculator", {
        "token": {
            type: Sequelize.INTEGER,
            primaryKey: true
        },
        "vehicleData":{
            type:Sequelize.JSON
        },
        insuringPartyData:{
            type:Sequelize.JSON
        },
        "policyDetailsData":{
            type:Sequelize.JSON
        },
        "installmentsData":{
            type:Sequelize.JSON
        },
        "coversData":{
            type:Sequelize.ARRAY(Sequelize.JSON)
        }
    }, {
        freezeTableName: true,
        timestamps: false
    });
    return MtplCalculator;
};

// CREATE TABLE mtplcalculator (token int vehicleData json,insuringPartyData json,policyDetailsData json,installmentsData json,coversData array of json)