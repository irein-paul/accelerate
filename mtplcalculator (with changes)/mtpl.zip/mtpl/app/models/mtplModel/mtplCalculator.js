const { verifyToken } = require("../../utils/authUtils");
const User = require("../userModel/userModel")

module.exports = (sequelize, Sequelize) => {
    const MtplCalculator = sequelize.define("mtplcalculator", {
        token: {
            type: Sequelize.INTEGER,
            primaryKey: true
        },
        vehicledata:{
            type:Sequelize.JSON
        },
        insuringpartydata:{
            type:Sequelize.JSON
        },
        policydetailsdata:{
            type:Sequelize.JSON
        },
        installmentsdata:{
            type:Sequelize.JSON
        },
        coversdata:{
            type:Sequelize.ARRAY(Sequelize.JSON)
        }
    }, {
        freezeTableName: true,
        timestamps: false
    });
    return MtplCalculator;
};

// CREATE TABLE mtplcalculator (token int vehicledata json,insuringpartydata json,policydetailsdata json,installmentsdata json,coversdata array of json)